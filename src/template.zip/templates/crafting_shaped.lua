local type = 'minecraft:crafting_shaped'

return {
    type = type,
    func = function(data)
        local ingredients = {}
        for k,v in ipairs(data.ingredients) do
            table.insert(ingredients, v.item or v.tag)
        end

        return Recipe(type,
            data.result.id,
            ingredients
        )
    end
}